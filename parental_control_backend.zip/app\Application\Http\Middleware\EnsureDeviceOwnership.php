<?php

namespace App\Application\Http\Middleware;

use App\Domain\Device\Repositories\DeviceRepositoryInterface;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureDeviceOwnership
{
    public function __construct(
        protected DeviceRepositoryInterface $deviceRepo
    ) {}

    public function handle(Request $request, Closure $next): Response
    {
        $uuid = $request->route('uuid');

        if (!$uuid) {
            return $next($request);
        }

        $device = $this->deviceRepo->findByUuid($uuid);

        if (!$device) {
            return response()->json([
                'success' => false,
                'message' => 'الجهاز غير موجود',
                'error'   => 'DEVICE_NOT_FOUND',
            ], 404);
        }

        if ($device->user_id !== $request->user()->id) {
            // تسجيل محاولة الوصول غير المصرح
            \App\Domain\Notification\Models\Notification::create([
                'user_id'    => $device->user_id,
                'device_id'  => $device->id,
                'title'      => '🚨 محاولة وصول مشبوهة',
                'message'    => 'محاولة وصول غير مصرح بها على جهازك من حساب آخر',
                'type'       => 'security_alert',
                'priority'   => 'urgent',
                'is_read'    => false,
                'created_at' => now(),
            ]);

            return response()->json([
                'success' => false,
                'message' => 'غير مصرح لك بالوصول لهذا الجهاز',
                'error'   => 'UNAUTHORIZED_DEVICE',
            ], 403);
        }

        // حقن الجهاز في الـ Request لاستخدامه لاحقاً بدون query إضافية
        $request->attributes->set('resolved_device', $device);

        return $next($request);
    }
}
