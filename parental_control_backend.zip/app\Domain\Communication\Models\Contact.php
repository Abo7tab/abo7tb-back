<?php

namespace App\Domain\Communication\Models;

use App\Domain\Device\Models\Device;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Contact extends Model
{
    protected $table = 'contacts';

    public $timestamps = false;

    protected $fillable = [
        'device_id',
        'name',
        'phone_number',
        'phone_numbers',
        'email',
        'is_favorite',
        'synced_at',
    ];

    protected $casts = [
        'phone_numbers' => 'array',
        'is_favorite'   => 'boolean',
        'synced_at'     => 'datetime',
    ];

    // ==================== Relations ====================

    public function device(): BelongsTo
    {
        return $this->belongsTo(Device::class);
    }

    // ==================== Helpers ====================

    public function getPrimaryNumberAttribute(): string
    {
        return $this->phone_number
            ?? ($this->phone_numbers[0] ?? '');
    }

    // ==================== Scopes ====================

    public function scopeFavorites($query)
    {
        return $query->where('is_favorite', true);
    }

    public function scopeSearch($query, string $keyword)
    {
        return $query->where(function ($q) use ($keyword) {
            $q->where('name',         'like', "%{$keyword}%")
              ->orWhere('phone_number', 'like', "%{$keyword}%");
        });
    }
}
