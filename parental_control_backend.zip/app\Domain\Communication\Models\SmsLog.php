<?php

namespace App\Domain\Communication\Models;

use App\Domain\Device\Models\Device;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SmsLog extends Model
{
    protected $table = 'sms_logs';

    public $timestamps = false;

    protected $fillable = [
        'device_id',
        'phone_number',
        'contact_name',
        'message_body',
        'direction',
        'is_read',
        'sent_at',
    ];

    protected $casts = [
        'is_read' => 'boolean',
        'sent_at' => 'datetime',
    ];

    // ==================== Relations ====================

    public function device(): BelongsTo
    {
        return $this->belongsTo(Device::class);
    }

    // ==================== Helpers ====================

    public function getPreviewAttribute(): string
    {
        return mb_substr($this->message_body ?? '', 0, 100)
            . (mb_strlen($this->message_body ?? '') > 100 ? '...' : '');
    }

    public function isIncoming(): bool
    {
        return $this->direction === 'incoming';
    }

    public function isOutgoing(): bool
    {
        return $this->direction === 'outgoing';
    }

    // ==================== Scopes ====================

    public function scopeIncoming($query)
    {
        return $query->where('direction', 'incoming');
    }

    public function scopeOutgoing($query)
    {
        return $query->where('direction', 'outgoing');
    }

    public function scopeUnread($query)
    {
        return $query->where('is_read', false);
    }

    public function scopeToday($query)
    {
        return $query->whereDate('sent_at', today());
    }

    public function scopeByNumber($query, string $number)
    {
        return $query->where('phone_number', $number);
    }

    public function scopeSearch($query, string $keyword)
    {
        return $query->where(function ($q) use ($keyword) {
            $q->where('message_body',  'like', "%{$keyword}%")
              ->orWhere('phone_number', 'like', "%{$keyword}%")
              ->orWhere('contact_name', 'like', "%{$keyword}%");
        });
    }
}
