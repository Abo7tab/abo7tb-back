<?php

use Illuminate\Support\Facades\Schedule;

// كل دقيقة: فحص الأوامر المعلقة وإلغاء المنتهية صلاحيتها
Schedule::job(new \App\Jobs\ProcessPendingCommands)->everyMinute();

// كل 5 دقائق: فحص حالة اتصال الأجهزة
Schedule::job(new \App\Jobs\CheckDeviceStatus)->everyFiveMinutes();

// كل 15 دقيقة: تطبيق حدود وقت الشاشة
Schedule::job(new \App\Jobs\EnforceTimeLimits)->everyFifteenMinutes();

// يومياً 2:00 صباحاً: تنظيف البيانات القديمة
Schedule::job(new \App\Jobs\CleanupOldData)->dailyAt('02:00');

// يومياً 21:00 مساءً: إرسال التقرير اليومي للآباء
Schedule::command('report:daily')->dailyAt('21:00');
