<?php

namespace App\Application\Http\Controllers\Api\V1\Device;

use App\Application\Http\Controllers\Controller;
use App\Application\Http\Requests\Device\AcceptConsentRequest;
use App\Application\Http\Requests\Device\RegisterDeviceRequest;
use App\Application\Http\Requests\Device\SendCommandRequest;
use App\Application\Http\Requests\Device\UpdateLocationRequest;
use App\Application\Http\Resources\DeviceResource;
use App\Domain\Device\DTOs\RegisterDeviceDTO;
use App\Domain\Device\DTOs\SendCommandDTO;
use App\Domain\Device\DTOs\UpdateLocationDTO;
use App\Domain\Device\Repositories\DeviceRepositoryInterface;
use App\Domain\Device\Services\CommandService;
use App\Domain\Device\Services\DeviceService;
use App\Domain\Device\Services\LocationTrackingService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DeviceController extends Controller
{
    public function __construct(
        protected DeviceService             $deviceService,
        protected CommandService            $commandService,
        protected LocationTrackingService   $locationService,
        protected DeviceRepositoryInterface $deviceRepo
    ) {}

    // ==================== للأب ====================

    /**
     * GET /api/v1/devices
     * جلب جميع أجهزة الأب
     */
    public function index(Request $request): JsonResponse
    {
        $devices = $this->deviceRepo->getUserDevices($request->user()->id);

        return $this->success([
            'devices' => DeviceResource::collection($devices),
            'total'   => $devices->count(),
        ]);
    }

    /**
     * POST /api/v1/devices/register
     * تسجيل جهاز جديد
     */
    public function register(RegisterDeviceRequest $request): JsonResponse
    {
        try {
            $dto    = RegisterDeviceDTO::fromArray($request->validated(), $request->user()->id);
            $device = $this->deviceService->registerDevice($dto);

            return $this->success(
                new DeviceResource($device),
                'تم تسجيل الجهاز بنجاح. في انتظار موافقة الطفل.',
                201
            );
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    /**
     * GET /api/v1/devices/{uuid}
     * تفاصيل جهاز واحد
     */
    public function show(Request $request, string $uuid): JsonResponse
    {
        $device = $this->deviceRepo->findByUuid($uuid);

        if (!$device || $device->user_id !== $request->user()->id) {
            return $this->error('الجهاز غير موجود.', 404);
        }

        return $this->success(new DeviceResource($device->load('consent')));
    }

    /**
     * POST /api/v1/devices/{uuid}/command
     * إرسال أمر للجهاز (من الأب)
     */
    public function sendCommand(SendCommandRequest $request, string $uuid): JsonResponse
    {
        $device = $this->deviceRepo->findByUuid($uuid);

        if (!$device || $device->user_id !== $request->user()->id) {
            return $this->error('الجهاز غير موجود.', 404);
        }

        try {
            $dto     = SendCommandDTO::fromArray($request->validated(), $device->id, $request->user()->id);
            $command = $this->commandService->sendCommand($dto);

            return $this->success([
                'command_uuid' => $command->uuid,
                'status'       => $command->status,
            ], 'تم إرسال الأمر بنجاح.');
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    // ==================== للجهاز (الطفل) ====================

    /**
     * POST /api/v1/devices/{uuid}/consent/accept
     * قبول الموافقة من الجهاز
     */
    public function acceptConsent(AcceptConsentRequest $request, string $uuid): JsonResponse
    {
        $device = $this->deviceRepo->findByUuid($uuid);

        if (!$device) {
            return $this->error('الجهاز غير موجود.', 404);
        }

        try {
            $consent = $this->deviceService->acceptConsent(
                $device,
                $request->validated('permissions', []),
                $request->ip(),
                $request->userAgent() ?? 'Unknown'
            );

            return $this->success([
                'consent_status' => $consent->consent_status,
                'given_at'       => $consent->consent_given_at?->toIso8601String(),
            ], 'تم قبول الموافقة بنجاح.');
        } catch (\RuntimeException $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    /**
     * POST /api/v1/devices/{uuid}/location
     * تحديث الموقع (من الجهاز)
     */
    public function updateLocation(UpdateLocationRequest $request, string $uuid): JsonResponse
    {
        $device = $this->deviceRepo->findByUuid($uuid);

        if (!$device) {
            return $this->error('الجهاز غير موجود.', 404);
        }

        $dto      = UpdateLocationDTO::fromArray($request->validated());
        $location = $this->locationService->updateLocation($device, $dto);

        return $this->success([
            'latitude'    => $location->latitude,
            'longitude'   => $location->longitude,
            'recorded_at' => $location->recorded_at?->toIso8601String(),
        ], 'تم تحديث الموقع.');
    }

    /**
     * GET /api/v1/devices/{uuid}/commands/pending
     * جلب الأوامر المعلقة (من الجهاز)
     */
    public function pendingCommands(string $uuid): JsonResponse
    {
        $device = $this->deviceRepo->findByUuid($uuid);

        if (!$device) {
            return $this->error('الجهاز غير موجود.', 404);
        }

        $commands = $this->commandService->getPendingCommands($device->id);

        return $this->success(['commands' => $commands]);
    }

    /**
     * PATCH /api/v1/commands/{uuid}/status
     * تحديث حالة الأمر (من الجهاز)
     */
    public function updateCommandStatus(Request $request, string $commandUuid): JsonResponse
    {
        $request->validate([
            'status' => 'required|in:completed,failed,executing',
            'result' => 'sometimes|array',
            'error'  => 'sometimes|string',
        ]);

        $command = $this->commandService->updateCommandStatus(
            $commandUuid,
            $request->status,
            $request->result ?? [],
            $request->error  ?? ''
        );

        return $this->success([
            'command_uuid' => $command->uuid,
            'status'       => $command->status,
        ]);
    }
}
