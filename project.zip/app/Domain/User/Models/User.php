<?php

namespace App\Domain\User\Models;

use App\Domain\Shared\Traits\Auditable;
use App\Domain\Shared\Traits\HasUuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, HasUuid, Auditable, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'uuid',
        'name',
        'email',
        'password',
        'password_hash',
        'phone',
        'avatar',
        'subscription_plan',
        'subscription_expires_at',
        'is_active',
        'email_verified_at',
        'last_login_at',
        'last_login_ip',
        'created_by',
        'updated_by',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'password_hash',
        'remember_token',
    ];

    /**
     * لو قاعدة البيانات بتستخدم password_hash بدل password
     * نحدد Laravel يستخدم password_hash للمصادقة
     */
    public function getAuthPasswordName(): string
    {
        // لو العمود password_hash موجود نستخدمه، وإلا password
        return $this->getOriginal('password_hash') !== null
            ? 'password_hash'
            : 'password';
    }

    public function getAuthPassword(): string
    {
        return $this->password_hash ?? $this->password ?? '';
    }

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at'       => 'datetime',
            'password'                => 'hashed',
            'is_active'               => 'boolean',
            'last_login_at'           => 'datetime',
            'subscription_expires_at' => 'date',
        ];
    }

    /**
     * Get all devices belonging to this user
     */
    public function devices()
    {
        return $this->hasMany(\App\Domain\Device\Models\Device::class);
    }
}
